<?php
namespace Ads\Config\Controller\Home;

class Home extends BaseController {

    public function __construct(){
        parent::__construct();
    }

    public function doIndex(){
    }


}
