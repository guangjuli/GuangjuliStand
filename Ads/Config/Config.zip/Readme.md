## data
> 对基本信息的获取

- gate 调用别的模型
- data 调用别的模型
- define 调用定义的数据
- sys 调用系统数据

注册 - 注册之后可以根据模块显示相对应的数据 没有注册的内容则返回空数据


## html

    - data/html/login   //登录界面
    - data/html/LoginPost   post响应


## Gate
    - data/gate/IsAdminlogin     //管理员是否登录
    - data/gate/ispost          //是否post模式

## Data

## define 定义的
    - data/define/AdminloginUrl       //登录地址
    - data/define/AdminloginUrlPost       //响应

    - data/define/AdminlogoutUrl      //退出地址
    - data/define/AdminMainUrl        //后台主界面地址
    - data/define/AdminBase           //后台主界面地址基础根路径

