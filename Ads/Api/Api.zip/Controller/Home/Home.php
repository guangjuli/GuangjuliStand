<?php
namespace Ads\Api\Controller\Home;

class Home extends BaseController {

    public function __construct(){
        parent::__construct();
    }

//    public function doIndex(){
//    }
//
//    public function doDet(){
//        return server('Smarty')->ads('group/home/index')->fetch('',[
//        ]);
//    }

}
